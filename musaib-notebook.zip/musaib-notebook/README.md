# musaib.notebook

A public second brain — notes I'm willing to share, resources I trust, and thoughts still in progress.

**Live site:** `https://<your-username>.github.io/<repo-name>/`

---

## Structure

```
.
├── index.html          ← the entire site (one file)
├── vault.js            ← auto-generated note database (DO NOT edit by hand)
├── build_vault.py      ← run this to regenerate vault.js from your .md files
├── notes/
│   ├── ML/             ← folder = sidebar section name
│   │   └── pca-svd.md
│   ├── OR/
│   │   └── newsvendor.md
│   ├── Poetry/
│   └── Cinema/
└── README.md
```

## Usage

### 1. Write notes

Put `.md` files inside `notes/` in whatever subfolder structure you like.
The **immediate subfolder name** becomes the sidebar section (e.g. `notes/ML/` → **ML** section).

Obsidian-style features supported:
- `[[Wikilinks]]` — cross-note links with hover preview
- `[[Note|Alias]]` — display text override
- `[[Note#Heading]]` — link to heading
- `$$...$$` / `$...$` — math via KaTeX
- `> [!tip] Title` — Obsidian callout blocks
- YAML frontmatter — `title`, `tags`, `date`, `aliases`

### 2. Rebuild vault.js

```bash
python build_vault.py
```

This scans `notes/` (and any other dirs in `NOTE_DIRS`) and writes `vault.js`.

### 3. Deploy

Push to GitHub. Enable **Pages** under Settings → Pages → source: `main` branch, `/ (root)`.

Your site is live at `https://<username>.github.io/<repo>/`.

---

## Math rendering

Uses [KaTeX](https://katex.org). Supported syntax:

| Syntax | Result |
|--------|--------|
| `$e^{i\pi} + 1 = 0$` | inline math |
| `$$\int_0^\infty e^{-x}\,dx = 1$$` | display math |
| `\(...\)` | inline math |
| `\[...\]` | display math |

## Customise

- **About tab**: edit the HTML in `index.html` around `id="tab-about"`
- **Resources**: edit the `resources` list at the bottom of `build_vault.py`, then rerun it
- **Site title**: change `musaib.notebook` in the `<header>` near the top of `index.html`
