---
title: PCA & SVD
tags: [ml, linear-algebra, math]
date: 2025-09-18
---

# PCA & SVD

## The Setup

Given data matrix $\mathbf{X} \in \mathbb{R}^{n \times d}$, find a lower-dimensional representation that preserves maximum variance.

## SVD Decomposition

$$\mathbf{X} = \mathbf{U} \mathbf{\Sigma} \mathbf{V}^\top$$

The best rank-$k$ approximation to $\mathbf{X}$ (Eckart-Young):

$$\mathbf{X}_k = \mathbf{U}_k \mathbf{\Sigma}_k \mathbf{V}_k^\top$$

Variance explained by first $k$ components:

$$\text{VarExplained} = \frac{\sum_{i=1}^k \sigma_i^2}{\sum_{i=1}^r \sigma_i^2}$$

See also: [[Newsvendor Model]]
