---
title: Newsvendor Model
tags: [or, inventory, probability]
date: 2025-10-20
---

# Newsvendor Model

Optimal order quantity under stochastic demand: $Q^* = F^{-1}(\text{CR})$

Critical ratio: $\text{CR} = \frac{p - c}{p - s}$

For normal demand $D \sim \mathcal{N}(\mu, \sigma^2)$:

$$Q^* = \mu + \sigma\,\Phi^{-1}(\text{CR})$$

See also: [[PCA & SVD]]
